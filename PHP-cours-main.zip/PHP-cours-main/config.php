<?php
    try {
        $bdd = new PDO('mysql:host=localhost;dbname=utilisateurs', 'root','');
    } 

    catch(PDOException $e) {
        
        die('Erreur'.$e->getMessage());
    } ?>

<?php 


//Fonction qui traduit la date du format machine au format EU

function dateEU($d) {
    //on cree l'objet temporel initialisé avec la bonne date
    $time = new DateTime($d);
    //On donne le résultat pour qu'il puisse être traité de plusieurs manières différentes (ecriture, envoi dans la base, etc)
    return $time->format('d/m/Y');
}

function datetimeEU($d) {
    $time = new DateTime($d);
    return $time->format('d/m/Y, G\hi');
}
?>