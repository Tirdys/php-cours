<?php 
    require_once 'config.php'; // ajout connexion bdd 
   // si la session existe pas soit si l'on est pas connecté on redirige
    if(!isset($_SESSION['user'])){
        header('Location:index.php');
        die();
    }


    // On récupere les données de l'utilisateur
    $req = $bdd->prepare('SELECT * FROM utilisateur WHERE token = ?');
    $req->execute(array($_SESSION['user']));
    $data = $req->fetch();


$reqLecture = $bdd->prepare('SELECT * FROM');
$data = $req->fetch();

//On execute la requete
$reqLecture->execute();

//On récupère les résultats de la requète sous forme d'un tableau
$tabLecture = $reqLecture->fetchAll();
   
?>

<!doctype html>
<html lang="fr">
  <head>
    <title></title>
     <meta charset="utf-8">
    
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="css/main.css">
      
   <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous"> 
      
  </head>

    
    <nav>
        <center><button type="button" class="mdp" style="margin-bottom: 10px; margin-top: 10px;" data-toggle="modal" data-target="#change_password">Changer mon mot de passe</button></center>
        <center><a type="button" class="mdp" href="deconnexion.php">Déconnexion</a></center>
        </nav>
    
  <body>
      
      
      
       <div class="container">
            <div class="col-md-12">
                <?php 
                        if(isset($_GET['err'])){
                            $err = htmlspecialchars($_GET['err']);
                            switch($err){
                                case 'current_password':
                                    echo "<div class='alert alert-danger'>Le mot de passe actuel est incorrect</div>";
                                break;

                                case 'success_password':
                                    echo "<div class='alert alert-success'>Le mot de passe a bien été modifié ! </div>";
                                break; 
                            }
                        }
                    ?>


                <div class="text-center">
                        <h1 class="p-5">Bonjour <?php echo $data['pseudo']; ?> !</h1>
                        <hr />